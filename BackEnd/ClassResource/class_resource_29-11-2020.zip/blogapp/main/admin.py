from django.contrib import admin
from main.models import *


admin.site.register(Category)
admin.site.register(Comment)
admin.site.register(Blog)
